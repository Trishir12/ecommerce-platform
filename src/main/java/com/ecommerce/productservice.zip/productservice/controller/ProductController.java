package com.ecommerce.productservice.controller;

import com.ecommerce.productservice.model.Product;
import com.ecommerce.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products") // Base path for all methods in this controller
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/add")
    public Product addProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable String id) {
        return productService.getProductById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets all products or filters by category if the param is provided.
     *
     * Example URLs:
     * GET /products          -> Returns all products.
     * GET /products?category=Clothes -> Returns only products in the "Clothes" category.
     */
    @GetMapping
    public List<Product> getAllProducts(@RequestParam(required = false) String category) {
        if (category != null && !category.isEmpty()) {
            return productService.getProductsByCategory(category);
        } else {
            return productService.getAllProducts();
        }
    }

    // --- NEW ENDPOINTS START HERE ---

    /**
     * Updates an existing product.
     * PUT /products/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable String id, @RequestBody Product productDetails) {
        return productService.updateProduct(id, productDetails)
                .map(ResponseEntity::ok) // Returns 200 OK with the updated product
                .orElse(ResponseEntity.notFound().build()); // Returns 404 Not Found
    }

    /**
     * Deletes a product.
     * DELETE /products/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable String id) {
        if (productService.deleteProduct(id)) {
            return ResponseEntity.noContent().build(); // Returns 204 No Content (success)
        } else {
            return ResponseEntity.notFound().build(); // Returns 404 Not Found
        }
    }
}