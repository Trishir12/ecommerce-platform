package com.ecommerce.productservice.service;

import com.ecommerce.productservice.model.Product;
import com.ecommerce.productservice.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    public Optional<Product> getProductById(String id) {
        return productRepository.findById(id);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // --- NEW METHODS START HERE ---

    /**
     * Finds products by their category.
     * @param category The category name to search for.
     * @return A list of matching products.
     */
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    /**
     * Updates an existing product.
     * @param id The ID of the product to update.
     * @param productDetails The product object with the new details.
     * @return An Optional containing the updated product, or empty if not found.
     */
    public Optional<Product> updateProduct(String id, Product productDetails) {
        // Find the existing product by its ID
        return productRepository.findById(id)
                .map(existingProduct -> {
                    // Update the fields of the existing product
                    existingProduct.setName(productDetails.getName());
                    existingProduct.setCategory(productDetails.getCategory());
                    existingProduct.setBrand(productDetails.getBrand());
                    existingProduct.setDescription(productDetails.getDescription());
                    existingProduct.setAttributes(productDetails.getAttributes());
                    existingProduct.setMerchants(productDetails.getMerchants());

                    // Save the updated product back to the database
                    return productRepository.save(existingProduct);
                });
    }

    /**
     * Deletes a product by its ID.
     * @param id The ID of the product to delete.
     * @return true if the product was found and deleted, false otherwise.
     */
    public boolean deleteProduct(String id) {
        // Check if a product with this ID exists
        if (productRepository.existsById(id)) {
            // If it exists, delete it and return true
            productRepository.deleteById(id);
            return true;
        }
        // If it doesn't exist, return false
        return false;
    }
}